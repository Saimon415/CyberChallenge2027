#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(){
	unsigned char password[20];

	printf("Bro inserisci la password per accedere al mio vault SUPER segreto\n");
	printf("Password: ");
	scanf("%19s", password);

	if (strlen(password) != 13){
		printf("Accesso negato!\n");
		return 1;
	}

	if (password[6] == 0x5F &&
	    password[0] == 0x50 &&
	    password[4] == 0x77 &&
	    password[9] == 0x43 &&
	    password[11] == 0x52 &&
	    password[10] == 0x75 &&
	    password[5] == 0x64 &&
	    password[1] == 0x61 &&
	    password[2] == 0x53 &&
	    password[8] == 0x69 &&
	    password[12] == 0x41 &&
	    password[3] == 0x53 &&
	    password[7] == 0x73){
		
		printf("Accesso Eseguito!!!\n");
		printf("Ciao sono Enrico Papi vuoi sapere quanto costa la tua auto\n");
		printf("CASS{***REDACTED***}\n");
	}else{
		printf("Enrico Papi non ti dirà niente\n");
	}
	exit(0);
}
