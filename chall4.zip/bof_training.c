#include <stdio.h>
#include <stdlib.h>
#include <string.h>
	
int main(){
	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);

	char password[30] = "Nonsochepasswordmette";
	char nome[16];

	printf("Inserisci il tuo nome: ");
	scanf("%s", nome);

	if (strcmp(password,"password123@?") == 0){
		printf("Hello BufferOverflow.\n");
		printf("CASS{***REDACTED***}");
	}else{
		printf("Nahhhh\n");
	}
	exit(0);
}
