#include <stdio.h>
#include <stdlib.h>

int main() {
    int pin;

    printf("Inserisci il PIN numerico: ");
    if (scanf("%d", &pin) != 1) {
        printf("Inserisci solo numeri!\n");
        return 1;
    }

    int secret = (pin * 3) - 15;
    secret = secret / 2;

    if (secret == 6132) {
        printf("PIN Corretto! CASS{***REDACTED***}\n");
    } else {
        printf("PIN Errato.\n");
    }

    exit(0);
}
